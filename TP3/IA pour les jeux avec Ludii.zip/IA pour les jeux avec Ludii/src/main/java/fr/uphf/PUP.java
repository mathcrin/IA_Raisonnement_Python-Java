package fr.uphf;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import game.Game;
import main.collections.FastArrayList;
import other.AI;
import other.RankUtils;
import other.context.Context;
import other.move.Move;

public class PUP extends AI
{
    //-------------------------------------------------------------------------

    /** Our player index */
    protected int player = -1;
    private Node root = null;

    //-------------------------------------------------------------------------

    /**
     * Constructor
     */
    public PUP()
    {
        this.friendlyName = "PUP";
    }

    //-------------------------------------------------------------------------

    @Override
    public Move selectAction
            (
                    final Game game,
                    final Context context,
                    final double maxSeconds,
                    final int maxIterations,
                    final int maxDepth
            )
    {
        if (root == null) {
            root = new Node(null, null, context);
        } else {
            root.context = context;
        }

        // We'll respect any limitations on max seconds and max iterations (don't care about max depth)
        final long stopTime = (maxSeconds > 0.0) ? System.currentTimeMillis() + (long) (maxSeconds * 1000L) : Long.MAX_VALUE;
        final int maxIts = (maxIterations >= 0) ? maxIterations : Integer.MAX_VALUE;

        int numIterations = 0;

        // Our main loop through MCTS iterations
        while
        (
                numIterations < maxIts && 					// Respect iteration limit
                        System.currentTimeMillis() < stopTime && 	// Respect time limit
                        !wantsInterrupt								// Respect GUI user clicking the pause button
        )
        {
            // Start in root node
            Node current = root;

            // Traverse tree
            while (true)
            {
                if (current.context.trial().over())
                {
                    // We've reached a terminal state
                    break;
                }

                current = select(current);

                if (current.visitCount == 0)
                {
                    // We've expanded a new node, time for playout!
                    break;
                }
            }

            Context contextEnd = current.context;

            if (!contextEnd.trial().over())
            {
                // Run a playout if we don't already have a terminal game state in node
                contextEnd = new Context(contextEnd);
                game.playout
                        (
                                contextEnd,
                                null,
                                -1.0,
                                null,
                                0,
                                -1,
                                ThreadLocalRandom.current()
                        );
            }

            // This computes utilities for all players at the of the playout,
            // which will all be values in [-1.0, 1.0]
            final double[] utilities = RankUtils.utilities(contextEnd);

            // Backpropagate utilities through the tree
            while (current != null)
            {
                current.visitCount += 1;
                for (int p = 1; p <= game.players().count(); ++p)
                {
                    current.scoreSums[p] += utilities[p];
                }
                current = current.parent;
            }

            // Increment iteration count
            ++numIterations;
        }
        Move selectedMove = finalMoveSelection(root);

        for (Node child : root.children) {
            if (child.moveFromParent.equals(selectedMove)) {
                root = child;
                break;
            }
        }

        return selectedMove;
    }

    /**
     * Selects child of the given "current" node according to UCB1 equation.
     * This method also implements the "Expansion" phase of MCTS, and creates
     * a new node if the given current node has unexpanded moves.
     *
     * @param current
     * @return Selected node (if it has 0 visits, it will be a newly-expanded node).
     */
    public static Node select(final Node current)
    {
        Node bestChild = null;
        double bestValue = Double.NEGATIVE_INFINITY;
        final double twoParentLog = 2.0 * Math.log(Math.max(1, current.visitCount));
        int numBestFound = 0;

        final int numChildren = current.children.size();
        final int mover = current.context.state().mover();

        for (int i = 0; i < numChildren; ++i)
        {
            final Node child = current.children.get(i);
            final double c = Math.sqrt(2); // Vous pouvez ajuster cette valeur
            final double exploit = child.scoreSums[mover] / child.visitCount;
            final double explore = c * Math.sqrt((Math.log(current.visitCount)) / child.visitCount);

            final double ucb1Value = exploit + explore;

            if (ucb1Value > bestValue)
            {
                bestValue = ucb1Value;
                bestChild = child;
                numBestFound = 1;
            }
            else if
            (
                    ucb1Value == bestValue &&
                            ThreadLocalRandom.current().nextInt() % ++numBestFound == 0
            )
            {
                // this case implements random tie-breaking
                bestChild = child;
            }
        }

        // If the node has been visited less than 5 times, keep only the best child
        if (current.visitCount < 5) {
            current.children.clear();
            current.children.add(bestChild);
        } else {
            // If the node has been visited 5 times or more, generate new children and add them to the parent's children list
            current.unexpandedMoves.forEach(move -> current.children.add(new Node(current, move, current.context)));
        }

        return bestChild;
    }

    /**
     * Selects the move we wish to play using the "Robust Child" strategy
     * (meaning that we play the move leading to the child of the root node
     * with the highest visit count).
     *
     * @param rootNode
     * @return
     */
    public static Move finalMoveSelection(final Node rootNode)
    {
        Node bestChild = null;
        int bestVisitCount = Integer.MIN_VALUE;
        int numBestFound = 0;

        final int numChildren = rootNode.children.size();

        for (int i = 0; i < numChildren; ++i)
        {
            final Node child = rootNode.children.get(i);
            final int visitCount = child.visitCount;

            if (visitCount > bestVisitCount)
            {
                bestVisitCount = visitCount;
                bestChild = child;
                numBestFound = 1;
            }
            else if
            (
                    visitCount == bestVisitCount &&
                            ThreadLocalRandom.current().nextInt() % ++numBestFound == 0
            )
            {
                // this case implements random tie-breaking
                bestChild = child;
            }
        }

        return bestChild.moveFromParent;
    }



    @Override
    public boolean supportsGame(final Game game)
    {
        if (game.isStochasticGame())
            return false;

        if (!game.isAlternatingMoveGame())
            return false;

        return true;
    }

    //-------------------------------------------------------------------------

    /**
     * Inner class for nodes used by example UCT
     *
     * @author Dennis Soemers
     */
    private static class Node
    {
        /** Our parent node */
        private final Node parent;

        /** The move that led from parent to this node */
        private final Move moveFromParent;

        /** This objects contains the game state for this node (this is why we don't support stochastic games) */
        private Context context;

        /** Visit count for this node */
        private int visitCount = 0;

        /** For every player, sum of utilities / scores backpropagated through this node */
        private final double[] scoreSums;

        /** Child nodes */
        private final List<Node> children = new ArrayList<Node>();

        /** List of moves for which we did not yet create a child node */
        private final FastArrayList<Move> unexpandedMoves;

        /**
         * Constructor
         *
         * @param parent
         * @param moveFromParent
         * @param context
         */
        public Node(final Node parent, final Move moveFromParent, final Context context)
        {
            this.parent = parent;
            this.moveFromParent = moveFromParent;
            this.context = context;
            final Game game = context.game();
            scoreSums = new double[game.players().count() + 1];

            // For simplicity, we just take ALL legal moves.
            // This means we do not support simultaneous-move games.
            unexpandedMoves = new FastArrayList<Move>(game.moves(context).moves());

            if (parent != null)
                parent.children.add(this);
        }

    }

    //-------------------------------------------------------------------------

}